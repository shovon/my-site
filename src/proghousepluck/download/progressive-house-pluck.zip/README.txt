This is a progressive house pluck preset that you can use on your own tracks.
You are free to use this as much as you want.

This is a derivation of another one, called Analog Piano 3, which come pre-
packaged with ZynAddSubFX.

I hope you guys like it, and I am really eager to hear the music that you will
make with it. :)

Instructions
============

For LMMS users:

Unzip the progressive-house-pluck.xpf file over to your LMMS' presets folder,
which is found in

- /home/your_username/lmms/presets on Linux, and
- C:\Users\your_username\lmms\presets on Windows.

---

For those using ZynAddSubFX as a plugin for other music production software:

- Unzip the progressive-house-pluck.xiz file anywhere.
- Start up the ZynAddSubFX plugin.
- Go to open the "Instrument" menu item, and click "Open Instrument."
- Open the progressive-house-pluck.xiz file.

Contact
=======

Please, feel free to email me at salehen.rahman@gmail.com.

License
=======

I released it under the Creative Commons license. Although, when sharing and
making derivative work of this preset, you have to attribute both the
ZynAddSubFX developers and myself, you don't, however, have to make attributions
when you only *used* it on a song. Using it and making derivative work of it are
two entirely different things.

Again, to summarize:
- you **don't* *have* to make any attribution to me when you simply *use* this
  preset on your tracks, but you are free to do so. However,
- you **have** to attribute both the ZynAddSubFX developers and myself, when
  producing your own preset off of this one, since I released it under the
  Creative Commons License. I am only asking you to make attribution for the
  sake of my own protection and that of the ZynAddSubFX developers; I don't want
  anyone to download it, make derivative work of it, and then claim that I, and
  the ZynAddSubFX developers stole the preset.
